/* Inkluderingsdirektiv: */
#include <stdio.h> /* printf. */
#include <stdlib.h> /* atoi för typomvandling. */
#include <stdint.h> /* uint8_t. */
#include <unistd.h> /* sleep och usleep. */
#include <gpiod.h> /* libgpiod, exempelvis gpiod_line*. */

/*************************************************************
* led_blink: Blinkar en lysdiod med valbar blinkhastighet.
*************************************************************/
static void led_blink(struct gpiod_line* led, const size_t delay_time)
{
   gpiod_line_set_value(led, 1);
   usleep(delay_time * 1000);
   gpiod_line_set_value(led, 0);
   usleep(delay_time * 1000);
   return;
}

/*************************************************************
* main: Ansluter en lysdiod samt en tryckknapp, vars
*       PIN-nummer matas in från terminalen. Vid nedtryckning
*       av tryckknappen blinkar lysdioden med en viss
*       fördröjning, annars med en annan, vilket också matas
*       in från terminalen. Om inte PIN-nummer och
*       fördröjningstid har angetts så avslutas programmet.
*************************************************************/
int main(const int argc, const char** argv)
{
   if (argc < 5) return 1;

   const uint8_t pin1 = (uint8_t)atoi(argv[1]);
   const uint8_t pin2 = (uint8_t)atoi(argv[2]);
   const size_t delay_on = (size_t)atoi(argv[3]);
   const size_t delay_off = (size_t)atoi(argv[4]);

   struct gpiod_chip* chip0 = gpiod_chip_open("/dev/gpiochip0");
   struct gpiod_line* led1 = gpiod_chip_get_line(chip0, pin1);
   struct gpiod_line* button1 = gpiod_chip_get_line(chip0, pin2);

   gpiod_line_request_output(led1, "LED1", 0);
   gpiod_line_request_input(button1, "BUTTON1");
   printf("%s at PIN %u configured as output!\n",
          gpiod_line_consumer(led1), gpiod_line_offset(led1));
   printf("%s at PIN %u configured as input!\n",
          gpiod_line_consumer(button1), gpiod_line_offset(button1));

   while (1)
   {
      if (gpiod_line_get_value(button1) == 1)
      {
         led_blink(led1, delay_on);
      }
      else
      {
         led_blink(led1, delay_off);
      }
   }
   return 0;
}
