// Inkluderingsdirektiv:
#include <unistd.h> /* sleep och usleep. */
#include <stdlib.h> /* atoi (alpha to integer). */

/**************************************************************
* main: Genererar fördröjning i millisekunder ifall detta har
*       passerats som ingående argument.
**************************************************************/
int main(const int argc, const char** argv)
{
   if (argc < 2) return 1;
   const size_t delay_time = (size_t)atoi(argv[1]);
   usleep(delay_time * 1000);
   return 0;
}

