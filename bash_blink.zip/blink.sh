#!/bin/bash

######################################################################################
# blink.sh: Skript för att kontinuerligt blinka en lysdiod, vars PIN-nummer samt
#           blinkhastigheten skall anges när skriptet körs via följande kommando:
#           $ sudo bash blink.sh <PIN> <delay_time>
#
#           Som exempel, för att blinka en lysdiod ansluten till PIN 17 var 
#           100:e millisekund, så kan följande kommando skrivas i terminalen:
#           $ sudo bash blink.sh 17 100
#
#           Det är också möjligt att köra programmet via make. Exempelvis kan
#           ovanstående kommando ersättas med följande:
#           $ make blink led1=17 delay_time=100
######################################################################################

######################################################################################
# blink: Blinkar en lysdiod med en valbar blinkhastighet. $1 utgörs av lysdiodens
#        PIN-nummer och $2 utgörs av blinkhastigheten mätt i millisekunder.
######################################################################################
blink()
{
   echo 1 > /sys/class/gpio/gpio$1/value
   make run delay_time=$2
   echo 0 > /sys/class/gpio/gpio$1/value
   make run delay_time=$2
}

######################################################################################
# main: Exporterar PIN för en lysdiod och sätter denna PIN till utport. Lysdioden
#       blinkar sedan kontinuerligt med angiven födröjningstid. $1 utgörs av 
#       lysdiodens PIN-nummer och $2 utgörs av blinkhastigheten mätt i millisekunder.
######################################################################################
main()
{
   echo $1 > /sys/class/gpio/export
   echo out > /sys/class/gpio/gpio$1/direction
   while true
   do
      blink $1 $2
   done
}

######################################################################################
# Anropar funktionen main vid start och passerar två argument från terminalen, där
# $1 utgörs av ett PIN-nummer till en lysdiod och $2 utgörs av blinkhastigheten
# mätt i millisekunder.
######################################################################################
main $1 $2
