// Inkluderingsdirektiv:
#include "led.hpp"

/*************************************************************************************
* led: Konstruktor f�r objekt av klassen led. Aktuell GPIO-linje initieras till
*      angiven PIN, angivet alias och aktivt h�g signal. Om alias samt aktivt h�g
*      ej har angivits anv�nds defaultv�rden.
**************************************************************************************/
gpio::led::led(const std::uint8_t pin, const char* alias, const std::uint8_t active_high)
{
   this->m_line = this->get_line(pin);
   gpiod_line_request_output(this->m_line, alias, 0);
   this->set_active_high(active_high);
   return;
}

/*************************************************************************************
* led: F�rflyttningskonstruktor, som flyttar minne f�r ing�ende argument till
*      aktuellt objekt. Undantag har inaktiverats f�r denna konstruktor.
**************************************************************************************/
gpio::led::led(led&& source) noexcept
{
   this->m_line = source.m_line;
   this->m_active_high = source.m_active_high;
   this->m_enabled = source.m_enabled;
   source.m_line = nullptr;
   source.m_active_high = 0x01;
   source.m_enabled = false;
   return;
}

/*************************************************************************************
* on: T�nder lysdiod.
**************************************************************************************/
void gpio::led::on(void)
{
   gpiod_line_set_value(this->m_line, this->m_active_high);
   this->m_enabled = true;
   return;
}

/*************************************************************************************
* off: Sl�cker lysdiod.
**************************************************************************************/
void gpio::led::off(void)
{
   gpiod_line_set_value(this->m_line, !this->m_active_high);
   this->m_enabled = false;
   return;
}

/*************************************************************************************
* toggle: Togglar lysdiod genom att unders�ka aktuellt tillst�nd och sedan l�ta
*         lysdioden anta motsatt tillts�nd.
**************************************************************************************/
void gpio::led::toggle(void)
{
   if (this->m_enabled)
   {
      this->off();
   }
   else
   {
      this->on();
   }
   return;
}

/*************************************************************************************
* blink: Blinkar lysdiod en g�ng med en valbar f�rdr�jningstid. F�r kontinuerligt
*        blinkande b�r denna medlemsfunktion anropas i en loop.
**************************************************************************************/
void gpio::led::blink(const std::size_t delay_time)
{
   this->toggle();
   this->delay(delay_time);
   return;
}