// Inkluderingsdirektiv:
#include "gpio.hpp"

/*************************************************************************************
* get_line: Returerar GPIO-linje tillh�rande gpiochip0.
**************************************************************************************/
gpiod_line* gpio::misc::get_line(const std::uint8_t pin)
{
   static gpiod_chip* chip0 = nullptr;
   if (!chip0) chip0 = gpiod_chip_open("/dev/gpiochip0");
   return gpiod_chip_get_line(chip0, pin);
}

/*************************************************************************************
* gpiod_line_new: Returerar initierad GPIO-linje, d�r anv�ndaren har m�jlighet att
*                 v�lja PIN-nummer, alias och datariktning.
**************************************************************************************/
gpiod_line* gpio::misc::gpiod_line_new(const std::uint8_t pin, const gpio::direction direction, 
                                       const char* alias)
{
   auto self = misc::get_line(pin);
   if (direction == gpio::direction::out)
   {
      gpiod_line_request_output(self, alias, 0);
   }
   else
   {
      gpiod_line_request_input(self, alias);
   }
   return self;
}

/*************************************************************************************
* gpiod_line_delete: Tar bort reservation fr�n en given GPIO-linje och s�tter
*                    motsvarande GPIO-linjepekare till null.
**************************************************************************************/
void gpio::misc::gpiod_line_delete(gpiod_line** self)
{
   gpiod_line_set_value(*self, 0);
   gpiod_line_release(*self);
   *self = nullptr;
   return;
}