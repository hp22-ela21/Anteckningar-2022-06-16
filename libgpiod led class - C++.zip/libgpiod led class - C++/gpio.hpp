#ifndef GPIO_HPP_
#define GPIO_HPP_

// Inkluderingsdirektiv:
#include <iostream>
#include <cstdio>
#include <gpiod.h>
#include <unistd.h>

/*************************************************************************************
* gpio: Namnrymd inneh�llande strukturer f�r implementering med libgpiod.
**************************************************************************************/
namespace gpio
{
   class misc; // Diverse attribut och medlemsfunktioner f�r GPIO-implementering.
   class led; // Implementering av lysdioder eller andra digitala utenheter.
   enum class direction { in, out }; // Datariktning.
}

/*************************************************************************************
* gpio: Inneh�ller diverse attribut samt medlemsfunktioner f�r GPIO-implementering.
*       Utg�r basklass f�r �vriga klasser i namnrymnden gpio.
**************************************************************************************/
class gpio::misc
{
protected:
   gpiod_line* m_line = nullptr; // GPIO-linjepekare, motsvarar PIN.
   std::uint8_t m_active_high = 0x01; // Aktivt h�g signal.
public:
   static void delay(const std::size_t delay_time) { usleep(delay_time * 1000); }
   void set_active_high(const std::uint8_t val) { this->m_active_high = val ? 1 : 0; }
   static gpiod_line* get_line(const std::uint8_t pin);
   static gpiod_line* gpiod_line_new(const std::uint8_t pin, const gpio::direction direction, 
                                     const char* alias = nullptr);
   static void gpiod_line_delete(gpiod_line** self);
};

#endif /* GPIO_HPP_ */