// Inkluderingsdirektiv:
#include "led.hpp"
#include <array>

/*************************************************************************************
* main: Ansluter tre lysdioder till PIN 17, 22 och 23, som implementeras via objekt
*       av klassen led. Pekare till dessa sedan till en vektor,
*       som sedan anv�ndas f�r att blinka lysdioderna var 100:e millisekund.
**************************************************************************************/
int main(void)
{
   gpio::led led1(17, "led1");
   gpio::led led2(22, "led2");
   gpio::led led3(23, "led3");

   std::array<gpio::led*, 3> leds = { &led1, &led2, &led3 };
   
   while (1)
   {
      for (auto& i : leds)
      {
         i->on();
         i->delay(100);
         i->off();
      }
   }

   return 0;
}