#ifndef LED_HPP_
#define LED_HPP_

// Inkluderingsdirektiv:
#include "gpio.hpp"

/*************************************************************************************
* led: Klass f�r enkel implementering av lysdioder eller andra digitala utenheter.
*      Anv�ndaren har m�jlighet att v�lja PIN-nummer, alias samt aktivt h�g signal
*      och motsvarande utenhet kan sedan t�ndas, sl�ckas, togglas och blinkas.
*      Objekt av denna klass kan inte kopieras eller tilldelas fr�n ett annat objekt.
*      Minnet f�r ett givet objekt av dock f�rflyttas via funktionen std::move. 
**************************************************************************************/
class gpio::led : public gpio::misc
{
protected:
   bool m_enabled = false; // Indikerar lysdiodens tillst�nd.
public:
   led(void) { }
   led(const std::uint8_t pin, const char* alias = nullptr, const std::uint8_t active_high = 0x01);
   ~led(void) { this->gpiod_line_delete(&this->m_line); }
   led(led&) = delete; // Kopieringskonstruktor borttagen.
   led& operator = (led&) = delete; // Tilldelningskonstruktor raderad.
   explicit led(led&& source) noexcept; // F�rflyttningskonstruktor.
   bool enabled(void) { return this->m_enabled; }
   std::uint8_t pin(void) { return static_cast<std::uint8_t>(gpiod_line_offset(this->m_line)); }
   const char* alias(void) { return gpiod_line_consumer(this->m_line); }
   void on(void);
   void off(void);
   void toggle(void);
   void blink(const std::size_t delay_time);
};

#endif /* LED_HPP_ */